import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.*; 
import javax.swing.*; 
import java.awt.event.*; 
import javax.swing.text.*; 
import processing.pdf.*; 
import java.awt.*; 
import processing.sound.*; 
import java.awt.AWTEvent; 
import java.awt.MouseInfo; 
import java.awt.Toolkit; 
import java.awt.event.AWTEventListener; 
import javax.swing.JFrame; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class choral_Beta_1_0_3cop extends PApplet {







float scg=0.5f;
String inp="<";
int markiert=color(200, 0, 0);
int noten=color(0, 0, 0);
final JEditorPane  jtp=new JEditorPane();
JButton jb=new JButton("\u00d6ffnen");
JButton jb2=new JButton("Speichern");
JButton jb3=new JButton("Pdf");
int ds=23;
int dz=20;
int dn=13;
int htextsize=80;
boolean pythag=false;
int offset_toene=2;
int schriftgroese=25;
float dauer=0.4f;
String speicherort="";
float pythar[]={440*pow(256/243, 1)*pow(9/8, 3), 440*pow(256/243, 2)*pow(9/8, 1), 440*pow(256/243, 1)*pow(9/8, 1), 440*pow(9/8, 1), 440, 391*pow(9/8, -1), 349*pow(9/8, -2), 330*pow(256/243, -1)*pow(9/8, -2), 293330*pow(256/243, -1)*pow(9/8, -3), 262*pow(256/243, -1)*pow(9/8, -4), 247*pow(256/243, -2)*pow(9/8, -4), 220*pow(9/8, -1), 191*pow(9/8, -2), 175*pow(256/243, -1)*pow(9/8, -3), 165, 147, 131, 124, 110, 95, 87};
float pythag_toene[]={640, 576, 512, 480, 432, 432*0.888f, 352, 320, 288, 256, 240, 216, 192, 176, 160, 144, 128, 120, 108, 96, 88};
float temp_toene[]={352*2, 659, 587, 523, 493, 440, 396, 352, 330, 293, 262, 247, 220, 191, 181, 175, 147, 131, 124, 110, 95, 90, 87};
float gtoene[]=temp_toene;
float stoene[]={352*2, 659, 587, 523, 493, 440, 396, 352, 330, 293, 262, 247, 220, 191, 181, 175, 147, 131, 124, 110, 95, 90, 87};
float toene[]={352*2, 659, 587, 523, 493, 440, 396, 352, 330, 293, 262, 247, 220, 191, 181, 175, 147, 131, 124, 110, 95, 90, 87};
float multip=1/2;
String speicherort_neuerChoral="";
float amps[]={1, 0.8f/9, 0.4f/9, 0.8f/9, 0.6f/9, 0.35f/9, 0.4f/9, 0.3f/9, 0.4f/9, 0.3f/9};
SinOsc oscs[]=new SinOsc[3500/250];

boolean abort=false;
ArrayList<Float> amp2=new ArrayList();
ArrayList<Float> del2=new ArrayList();
public String rep(String input, String in, String out) {
  // println(input+" in "+in+" out "+out);
  String ins[]=input.split(in);
  String ret="";
  if (ins.length==0) return input;
  for (int i=0; i<ins.length-1; i++) ret+=ins[i]+out;
  ret+=ins[ins.length-1];
  return ret;
}
public void amp2(float del, float amp) {
  amp2.add(amp);
  del2.add(del);
  amp2.add(-1.0f);
  del2.add(0.05f);
}
boolean organ=true;/*
void amp(float del, float amp) {
 println(amp);
 SinOsc s=new SinOsc(this);
 SawOsc s2=new SawOsc(this);
 SawOsc s3=new SawOsc(this);
 SawOsc s4=new SawOsc(this);
 TriOsc s5=new TriOsc(this);
 TriOsc s6=new TriOsc(this);
 TriOsc s7=new TriOsc(this);
 SinOsc s8=new SinOsc(this);
 s.amp(amps[0]);
 if (!pythag) {
 s2.amp(amps[1]);
 s3.amp(amps[2]);
 s4.amp(amps[3]);
 s5.amp(amps[4]);
 s6.amp(amps[5]);
 s7.amp(amps[6]);
 s8.amp(amps[6]);
 } else {
 s3.amp(0.28);
 s5.amp(0.28);
 }
  /*s2.amp(0);
 s3.amp(0.18);
 s4.amp(0.2);
 s5.amp(0.0);
 s6.amp(0.0);*/
/*
  if (organ) {
 s.amp(3.5/4.5);
 s2.amp(4.25/4.5);
 s3.amp(2/4.5);
 s4.amp(1.5/4.5);
 s6.amp(4/4.5);
 s5.amp(0.3/4.5);
 s7.amp(3/4.5);
 s8.amp(1.5/4.5);
 }
 if (!abort) for (int i=0; i<oscs.length; i++) oscs[i].freq(amp*multip+amp*multip*i);
 if (!abort) for (int i=0; i<amps.length; i++) oscs[i].amp(amps[i]);
 if (!abort) for (int i=0; i<oscs.length; i++) oscs[i].play();
 if (!abort) delay((int)(del*1000));
 for (int i=0; i<oscs.length; i++) oscs[i].stop();
 if (!abort) delay(50);
 redraw();
 }*/

final Zeile z=new Zeile();
final Page page=new Page();
final JLabel warnings=new JLabel("Keine Fehler gefunden");
String file_in="";
boolean begin=false;                                
JPanel jpan=new JPanel();
JFrame jf=new JFrame("Code");
JFrame jf1=new JFrame("Erkl\u00e4rung");
JScrollPane listScroller2 = new JScrollPane(jtp);
PGraphicsPDF pdf;
int ts=20;
int timer=0;
public void setup() {
  for (int i=0; i<oscs.length; i++) oscs[i]=new SinOsc(this);
  for (int i=0; i<oscs.length; i++) oscs[i].amp(0);
  for (int i=0; i<oscs.length; i++) oscs[i].add(1/(i+2));
  if (pythag) gtoene=pythag_toene;
  textSize(ts);
  readinsetup();
  page.scal=0.5f;
  frameRate(30);
  
  PImage titlebaricon = loadImage("Icon.png");
  println(titlebaricon.toString());
  surface.setIcon(titlebaricon);
  surface.setTitle("Choral");
  background(255);
  if (args!=null) fileSelected(new File(args[0])); 
  else {
    selectInput("\u00d6ffnen:", "fileSelected");
  }
  scale(2.5f);
}
boolean trigger_once=true;
int offsetText=0;
public void readinsetup() {
  String read[]=loadStrings("Einstellungen.ini");
  for (int i=0; i<read.length; i++) {
    String var=read[i].split(":")[0].replace(" ", "");
    String par[]={};
    if (read[i].split(":").length>1) par=read[i].split(":")[1].replace(" ", "").split(" ");
    if (read[i].split(":").length>1) switch(var) {

    case "Geschwindigkeit":
      dauer=0.4f*PApplet.parseFloat(par[0]);
      break;
    case "Tonverschiebung":
      multip=PApplet.parseFloat(par[0]);
      break;
    case "Schriftgroese":
      schriftgroese=PApplet.parseInt(par[0]);
      break;
    case "SchriftgroeseUeberschrift":
      htextsize=PApplet.parseInt(par[0]);
      break;
    case "Text-Verschiebung":
      offsetText=PApplet.parseInt(par[0]);
      break;
    case "Liedtext-Groese":
      textSize(ts=PApplet.parseInt(par[0]));
      break;
    case "Notenabstand":
      ds=PApplet.parseInt(par[0]);
      break;
    case "Zeilenabstand":
      dz=PApplet.parseInt(par[0]);
      break;
    case "Notengroese":
      dn=PApplet.parseInt(par[0]);
      break;
    case "Pdf-Speicherort":
      speicherort=(" "+read[i]).split("Pdf-Speicherort")[1];
      println(speicherort);
      while (speicherort.substring(0, 1).equals(" ")||speicherort.substring(0, 1).equals(":")) {
        println(speicherort);
        speicherort=speicherort.substring(1, speicherort.length());
      }
      println(speicherort_neuerChoral);
      break;
    case "Amplitude-Grundton":
      amps[0]=PApplet.parseFloat(par[0]);
      break;
    case "Amplitude-Oktave":
      amps[1]=PApplet.parseFloat(par[0]);
      break;
    case "Amplitude-2Oktaven":
      amps[3]=PApplet.parseFloat(par[0]);
      break;
    case "Amplitude-Quinte2Oktaven":
      amps[4]=PApplet.parseFloat(par[0]);
      break;
    case "Amplitude-QuinteOktave":
      amps[2]=PApplet.parseFloat(par[0]);
      break;
    case "Amplitude-Terz2Oktaven":
      amps[5]=PApplet.parseFloat(par[0]);
      break;
    case "Choral-Speicherort":
      speicherort_neuerChoral=(" "+read[i]).split("Choral-Speicherort")[1];
      println(speicherort_neuerChoral);
      while (speicherort_neuerChoral.substring(0, 1).equals(" ")||speicherort_neuerChoral.substring(0, 1).equals(":")) {
        println(speicherort_neuerChoral);
        speicherort_neuerChoral=speicherort_neuerChoral.substring(1, speicherort_neuerChoral.length());
      }
      println(speicherort_neuerChoral);
      break;

    case "Amplitude-Oberton-1":
      amps[1]=PApplet.parseFloat(par[1]);
      break;
    case "Amplitude-Oberton-2":
      amps[2]=PApplet.parseFloat(par[2]);
      break;
    case "Amplitude-Oberton-3":
      amps[3]=PApplet.parseFloat(par[3]);
      break;
    case "Amplitude-Oberton-4":
      amps[4]=PApplet.parseFloat(par[4]);
      break;
    case "Amplitude-Oberton-5":
      amps[5]=PApplet.parseFloat(par[5]);
      break;
    case "Amplitude-Oberton-6":
      amps[6]=PApplet.parseFloat(par[6]);
      break;
    case "Amplitude-Oberton-7":
      amps[7]=PApplet.parseFloat(par[7]);
      break;
    case "Amplitude-Oberton-8":
      amps[8]=PApplet.parseFloat(par[8]);
      break;
    case "Amplitude-Oberton-9":
      amps[9]=PApplet.parseFloat(par[9]);
      break;
    }
  }
}
public void delay2(int time) {
  for (int i=0; i<time; i++) {
    if (i%10==0) redraw();
    delay(1);
  }
}
public void animation() {
  warnings.setText("");
  page.insert(jtp.getText().split("\n"));
  background(255);
  //println(jtp.getText().split("\n")[0]);
  fill(0);
  page.paint();
}
boolean prioritizeExport=false;
@Override
  public void mouseClicked() {
  abort=true;
}
public void draw() {
  if (timer==0&&amp2.size()>1) {
    if(amp2.get(0)>=0)for (int i=0; i<oscs.length; i++) oscs[i].stop();
    amp2.remove(0);
    del2.remove(0);
    if(amp2.get(0)>=0)if (!abort) for (int i=0; i<oscs.length; i++) oscs[i].freq(amp2.get(0)*multip+amp2.get(0)*multip*i);
    if (!abort) for (int i=0; i<amps.length; i++) oscs[i].amp(amps[i]);
    if(amp2.get(0)>=0)if (!abort) for (int i=0; i<oscs.length; i++) oscs[i].play();
    if (!abort) timer=(int)(del2.get(0)*frameRate);
  } else if (timer!=0)timer--;
  println(amp2.size(),timer);
  println(amp2.size());
  PointerInfo pointerInfo = MouseInfo.getPointerInfo();
  if (prioritizeExport) {
    prioritizeExport=false;
    beginRecord(PDF, file_in+".pdf");
    animation();
    //pdf = (PGraphicsPDF)beginRecord(PDF, "Lines.pdf");
    //pdf.nextPage();
    endRecord();
  }
  if (trigger_once) {
    create_Window();
    trigger_once=false;
  }
  if (begin&&frameCount%5==0) {
    beginRecord(PDF, "Lines2.pdf");
    animation();
    //pdf = (PGraphicsPDF)beginRecord(PDF, "Lines.pdf");
    //pdf.nextPage();
    endRecord();
  }
}
public void read_in_File(String select) {

  println("Lade Datei:" + select);
  file_in=select;

  String p[]=loadStrings(file_in);
  if (p.length==0) p=new String[]{"scal 1", " "};
  begin=true;
  //println(p[0]);
  String prog="";
  for (int i=0; i<p.length; i++) prog+=p[i]+"\n";
  jtp.setText(prog);
}
public void fileSelected(File selection) {
  if (selection == null) {
    println("Warnung: Keine Datei Ausgew\u00e4hlt erstelle neue Datei");
    saveStrings("unnnamed.txt", new String[]{});
    file_in="unnamed.txt";
  } else {

    println("Lade Datei:" + selection.getAbsolutePath());
    file_in=selection.getAbsolutePath();
  }
  println(file_in);
  String p[]=loadStrings(file_in);
  if (p.length==0) p=new String[]{"scal 0.65", "text 1 \u00dcberschrift", "sc 2 0", ""};
  begin=true;
  //println(p[0]);
  String prog="";
  for (int i=0; i<p.length; i++) prog+=p[i]+"\n";
  jtp.setText(prog);
  page.insert(p);
  // jf1.setVisible(true);
  fill(0);
  page.paint();
}
public void create_Window() {

  Style style, fontsize;

  Font f=new Font(Font.SANS_SERIF, schriftgroese/2, schriftgroese);
  jtp.setFont(f);

  Container c=jf.getContentPane();
  Container con=jf1.getContentPane();
  c.add(listScroller2);

  JPanel contp=new JPanel();
  contp.setLayout(new GridBagLayout());

  String erkl[]={"Jede Zeile enth\u00e4lt einen Befehl", "Jeder dieser erwartet Eingaben:", "Tonh\u00f6he h", "pun h1 m: Erstellt eine Einzelnote "};
  for (int i=0; i<erkl.length; i++) {
    GridBagConstraints c1=new GridBagConstraints();
    c1.gridx=0;
    c1.gridy=i;
    c1.gridwidth=2;
  }

  jpan.setBounds(0, 0, 280, 350);
  jb.setBounds(100, 370, 140, 100);

  jf.setSize(325, 500);
  jf1.setSize(280, 100);
  JPanel jpanel=new JPanel();
  JPanel jpanel2=new JPanel();
  jpanel2.add(warnings);
  JButton pla=new JButton("Abspielen");

  ActionListener al=new ActionListener() {
    public void actionPerformed(ActionEvent e) {

      selectInput("\u00d6ffnen:", "fileSelected");
    }
  };
  jb.addActionListener(al);
  pla.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {

      page.play();
    }
  }
  );
  ActionListener sp=new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      saveStrings(file_in, jtp.getText().split("\n"));
    }
  };
  jb2.addActionListener(sp);
  ActionListener pd=new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      prioritizeExport=true;
    }
  };
  jb3.addActionListener(pd);

  jpanel.setLayout(new GridBagLayout());
  GridBagConstraints c1=new GridBagConstraints();
  c1.gridx=0;
  c1.gridy=0;
  c1.gridwidth=1;
  jpanel.add(jb, c1);
  GridBagConstraints c2=new GridBagConstraints();
  c2.gridx=1;
  c2.gridy=0;
  c2.gridwidth=1;
  jpanel.add(jb2, c2);
  GridBagConstraints c3=new GridBagConstraints();
  c3.gridx=2;
  c3.gridy=0;
  c3.gridwidth=1;
  jpanel.add(jb3, c3);
  GridBagConstraints c4=new GridBagConstraints();
  c4.gridx=3;
  c4.gridy=0;
  c4.gridwidth=1;
  jpanel.add(pla, c4);

  c.add(jpanel, "South");
  //getSurface().getNative().getContentPane().add();
  jf.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
  jf.setVisible(true);
}
public void keyTyped() {
  println(inp);
  if (key==' ') jtp.setText(jtp.getText()+"\ngap");
  else if (key==ENTER) if (inp.substring(0, min(1, inp.length())).equals("<")) jtp.setText(jtp.getText()+"\nnewline"); 
  else jtp.setText(jtp.getText()+"\n"+inp);
  else if (key==BACKSPACE) {
    if (inp.equals("<")||inp.equals("")) {
      String[] sp=jtp.getText().split("\n");
      String st="";
      for (int i=0; i<sp.length-1; i++) st+=sp[i]+"\n";
      jtp.setText(st);
    } else inp="<";
  } else if (key=='N'||(procesCRTL&&procesN)) {
    final ImageIcon icon2=new ImageIcon(sketchPath("")+"\\data\\Icon.png");
    String datname=  speicherort_neuerChoral+"\\"+JOptionPane.showInputDialog(null, "Name der neuen Datei", "Datei erstellen", JOptionPane.INFORMATION_MESSAGE, icon2, null, "")+".choral";
    println(datname);  
    if (!datname.equals(speicherort_neuerChoral+"\\null.choral"))saveStrings(datname, new String[]{"scal 0.65", "text 1 \u00dcberschrift", "sc 2 0", });
    //fileSelected(new File(datname));
    if (!datname.equals(speicherort_neuerChoral+"\\null.choral"))read_in_File(  datname);
  } else if (key=='S'||(procesCRTL&&procesS)) {
    final ImageIcon icon2=new ImageIcon(sketchPath("")+"\\data\\Icon.png");
    String datname=speicherort_neuerChoral+"\\"+JOptionPane.showInputDialog(null, "Name der Datei", "Speichern als", JOptionPane.INFORMATION_MESSAGE, icon2, null, "")+".choral";
    if (!datname.equals(speicherort_neuerChoral+"\\null.choral"))saveStrings(datname, new String[]{jtp.getText()});
    if (!datname.equals(speicherort_neuerChoral+"\\null.choral"))read_in_File(  datname);
  } else if (key=='R'||(procesCRTL&&procesR)) readinsetup();
  else
    if (key=='?') save(file_in+"Screenshot.png");
    else {
      if (inp.substring(0, min(1, inp.length())).equals("<")||inp.substring(0, min(1, inp.length())).equals("q")||inp.substring(0, min(1, inp.length())).equals("p")) {
        if (key=='p') inp="pa";
        if (key=='q') inp="q";
        else if (key!='p')
          inp+=""+((key=='b')?"":" ")+key;
        if (PApplet.parseInt(""+key)!=0||key=='0') {
          jtp.setText(jtp.getText()+"\n"+inp);
          inp="<";
        }
      } else {
        inp+=key;
      }
    }

  if (key=='.') {
    abort=true;
    inp="<";
  }

  if (key=='#') inp="";
}

boolean procesCRTL=false;
boolean procesN=false;
boolean procesS=false;
boolean procesR=false;
public void keyPressed() {
  if (keyCode==17)
    procesCRTL=true;
  if (keyCode==82)
    procesR=true;
  if (keyCode==78)
    procesN=true;
  if (keyCode==83)
    procesS=true;
}

public void keyReleased() {
  if (keyCode==17)
    procesCRTL=false;
  if (keyCode==82)
    procesR=false;
  if (keyCode==78)
    procesN=false;
  if (keyCode==83)
    procesS=false;
}
public void mousePressed() {
  println("help");
}
class B_ {
  String text;
  int n;
  int n1;
  int n2;
  B_(int h) {
    n=h;
  }
  public void play(int r){
    /*if(!pythag)toene[offset_toene+n]/=pow(2,(float)((float)1/(float)13));else */toene[offset_toene+n]/=PApplet.parseFloat(256)/PApplet.parseFloat(243);
  }
  public void paint(int nr) {
    strokeWeight(2);
    int l=0;
    //textMode(CENTER);
    //text(text,nr*18+50,120);
    if (n<n1) l=20;
    line(nr*ds, 30+((float) n)*10-15, nr*ds, 30+((float) n)*10+5 );
    line(nr*ds, 30+((float) n)*10+5, nr*ds+7, 30+((float) n)*10+8 );
    line(nr*ds+7, 30+((float) n)*10+8, nr*ds+7, 30+((float) n)*10 );
    line(nr*ds, 30+((float) n)*10-3, nr*ds+7, 30+((float) n)*10 );
    strokeWeight(1);
  }
}
class Clivis {
  String text;
  int n;
  int n1;
  boolean over=false;
  int l=dn;
  Clivis(int u, int o, String te) {
    n=u;
    n1=o;
    text=te;
  }
  public void play(int r) {
    amp2(dauer*0.8f, toene[offset_toene+(int)n]);
    amp2(dauer*0.7f, toene[offset_toene+(int)n1]);
    toene[offset_toene+n]=stoene[offset_toene+n];
    toene[offset_toene+n1]=stoene[offset_toene+n1];
  }
  public void paint(int nr) {
    //textMode(CENTER);
    //text(text,nr*dn+50,120);
    rect(nr*ds+10*text.length()+l, 30+((float) n1)*dz/2-10, dn, dn);
    rect(nr*ds+10*text.length(), 30+((float) n)*dz/2-10+(dz-dn)/2, dn, dn);
    line(nr*ds+10*text.length()+dn, 30+((float) n1)*dz/2-10+(dz-dn)/2, nr*ds+10*text.length()+dn, 30+((float) n)*dz/2-10+dn);
    if (n1>n) line(nr*ds, 30+((float) n)*dz/2-10+(dz-dn)/2, nr*ds, 30+((float) n)*dz/2-10+(dz-dn)/2+3*dn);
  }
}






/*
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }*/
    private static class Listener implements AWTEventListener {
        public void eventDispatched(AWTEvent event) {
            System.out.print(MouseInfo.getPointerInfo().getLocation() + " | ");
            System.out.println(event);
        }
    }
class Group {
  String text="";
  float pk=0;
  int l=0;
  int lx=0;
  Komponenten k[];
  Group(Komponenten[] n, String t, int x) {
    text=t;
    k=n;
    for (int i=0; i<n.length; i++) if (n[i]!=null) pk+=n[i].pcount;
    pk=max(pk, text.length())+x;
    lx=x;
  }
  //int leng=text.length();
  public void paint() {

    l=lx;
    text(text, lx*ds, 130);
    for (int i=0; i<k.length; i++) {
      if (k[i]!=null) k[i].paint(l);
      if (k[i]!=null) l+=k[i].pcount;
    }
  }
  public void play() {

    l=lx;
    text(text, lx*ds, 130);
    for (int i=0; i<k.length; i++) {
      if (k[i]!=null) k[i].play(l);
      if (k[i]!=null) l+=k[i].pcount;
    }
  }
}
class Komponenten {
  float pcount=1;
  int n[]={0, 0};
  int l;
  String storage="";
  Pes_ p1_;
  Punctum_ pi;
  Torculus_ t_;
  Paus_ p;
  Schluessel_ s;
  B_ b=null;
  Qui q;
  Clivis cl=null;
  Komponenten(Pes_ p, Punctum_ pu, Torculus_ t) {
    p1_=p;
    if (p!=null) if (p.n<p.n1) {
      pcount=2;
    } else {
      pcount=1;
    }
    pi=pu;
    if (pi!=null) pcount=1;
    t_=t;
  }
  Komponenten(Pes_ p) {
    p1_=p;
    if (p!=null) if (p.n<p.n1) {
      pcount=2;
    } else {
      pcount=1;
    }
    pi=null;
    t_=null;
  }
  Komponenten(Clivis p) {
    p1_=null;
    pcount=2;
    pi=null;
    t_=null;
    cl=p;
  }
  Komponenten(Punctum_ pu) {
    p1_=null;
    pi=pu;
    t_=null;
    pcount=(pu.t==3)?0:1;
  }
  Komponenten(Qui q) {
    this.q=q;
    pcount=0;
  }
  Komponenten(B_ b) {
    p1_=null;
    pi=null;
    t_=null;
    this.b=b;
  }
  Komponenten(Torculus_ t) {
    p1_=null;
    pi=null;
    t_=t;
    pcount=4-t.tp-2+t.dk;
  }
  Komponenten(Paus_ p) {
    this.p=p;
    pcount=2;
  }
  Komponenten(Schluessel_ s) {
    this.s=s;
    pcount=2;
  }
  Komponenten(String st) {
    storage=st;
    pcount=0;
  }
  int m2=color(0, 0, 0);
  Komponenten(int m) {
    pcount=0;
    this.m2=m;
  }
  Komponenten() {
    pcount=1;
  }
  public void paint(int r) {
    if (p!=null) p.paint(r);
    if (p1_!=null) p1_.paint(r);
    if (pi!=null) pi.paint(r);
    if (t_!=null) t_.paint(r);
    if (b!=null) b.paint(r);
    if (s!=null) s.paint(r);
    if (q!=null) q.paint(r);
    if (cl!=null) cl.paint(r);
    if (!storage.equals("")) text(storage, r*ds, 130*(dz)/20+ts-20+offsetText);
    //if(p!=null||p1_!=null||pi!=null||t_!=null||b!=null||s!=null||q!=null||!storage.equals("")){
    fill(m2);
    stroke(m2);
    // }
  }
  public void play(int r) {
    if(!abort) if (p!=null) p.play(r);
    if(!abort) if (p1_!=null) p1_.play(r);
    if(!abort) if (pi!=null) pi.play(r);
    if(!abort) if (t_!=null) t_.play(r);
    if(!abort) if (b!=null) b.play(r);
    if(!abort) if (s!=null) s.play(r);
    if(!abort) if (q!=null) q.play(r);
    if(!abort) if (cl!=null) cl.paint(r);
  }
}
class Page {
  Zeile[] zeilen;
  Page() {
  }
  int tt=0;
  float scal=0.5f;
  String text;
  public void insert(String[] str) {
    warnings.setText("Keine Fehler gefunden");
    if (str.length>0) {
      String scale[]=str[0].split(" ");
      if (scale[0].equals("scal")) try {
        scal=PApplet.parseFloat(scale[1]);
        if (scal==0) scal=0.65f;
      }
      catch(Exception e) {
        if (warnings.getText().equals("Keine Fehler gefunden")) warnings.setText("");
        warnings.setText(warnings.getText()+"\n"+"Fehler in Zeile "+0);
      }
      if (str.length>1) { 
        try {
          scale=str[1].split(" ");
          tt=PApplet.parseInt(scale[1]);
          if (scale[0].equals("text"))
            text=str[1].substring(7, str[1].length());
        }
        catch(Exception e) {
          if (warnings.getText().equals("Keine Fehler gefunden")) warnings.setText("");
          warnings.setText(warnings.getText()+"\n"+"Fehler in Zeile "+1);
        }
      }
      for (int j=1; j<45; j++) {
        for (int i=0; i<str.length; i++) {
          String kl="";
          for (int k=1; k<j; k++) kl+="+";
          str[i]=rep(str[i], "\\+"+(j-1)+"\\+", kl);
        }
      }
      scg=scal;
      String doc="";
      for (int i=0; i<str.length; i++) {
        int in=str[i].indexOf("+");
        if (in!=-1&&in!=str[i].length()) {
          if(i+1<str.length) str[i+1]+="\n"+str[i].substring(in+1, str[i].length());
          str[i]=str[i].substring(0, in);
        }
      }
      for (int i=0; i<str.length; i++) doc+=str[i]+((i==str.length-1)?"":"\n");
      doc=rep(doc,"#","gap \n");
      doc=rep(doc,"$","gap \n");
      String lines[]=doc.split("newline");
      zeilen=new Zeile[lines.length];
      for (int i=0; i<zeilen.length; i++) {
        //println(i);
        if (i==0) zeilen[i]=new Zeile(); 
        else zeilen[i]=new Zeile(zeilen[i-1].x, null);
        zeilen[i].insert(lines[i].split("\n"));

        //println(zeilen[i].x==null);
      }
    }
  }
  public void paint() {
    scale(scal);
    textSize(htextsize);
    if (text!=null&&!text.equals("")) {
      textAlign(LEFT);
      if (tt==0)  text(text, 50/scal, 80/scal);
      textAlign(CENTER);
      if (tt==1)  text(text, width/2/scal, 80/scal);
      textAlign(RIGHT);
      if (tt==2)  text(text, (width-50)/scal, 80/scal);
    } else
      translate(0, ( -130));
    textSize(ts);
    textAlign(LEFT);
    for (int i=0; i<zeilen.length; i++) {
      //println(i);
      translate(0, ( 130));
      zeilen[i].scal=scal;
      zeilen[i].paint();
    }
    translate(0, 0);
  }
  public void play() {
    amp2.clear();
    del2.clear();
    amp2.add(-1.0f);
    del2.add(0.1f);
    for (int i=0; i<zeilen.length; i++) {
      zeilen[i].play();
    }
    amp2.add(-1.0f);
    del2.add(0.1f);
    abort=false;
  }
}
class Paus_ {
  int l=0;
  Paus_(int l) {
    this.l=l;
  }
  public void play(int r){
  amp2((dauer/4*7),-1.0f);
  }
  public void paint(int pos) {
    if (l==1) line(pos*ds+10, 25, pos*ds+10, 35);
    if (l==2) line(pos*ds+10, 40, pos*ds+10, 80);
    if (l==3) line(pos*ds+10, 30, pos*ds+10, 90);
    if (l==4) line(pos*ds+7, 30, pos*ds+7, 90);
    if (l==4) line(pos*ds+12, 30, pos*ds+12, 90);
  }
}
class Pes_ {
  String text;
  int n;
  int n1;
  boolean over=false;
  int l=0;
  Pes_(int u, int o, String te) {
    n=u;
    n1=o;
    text=te;
  }
  public void play(int r) {
    amp2(dauer*0.8f, toene[offset_toene+(int)n]);
    amp2(dauer*0.7f, toene[offset_toene+(int)n1]);
    toene[offset_toene+n]=stoene[offset_toene+n];
    toene[offset_toene+n1]=stoene[offset_toene+n1];
  }
  public void paint(int nr) {
    if (n<n1||over) l=dn;
    //textMode(CENTER);
    //text(text,nr*dn+50,120);
    //println(nr,ds,l,dz,dn,n1,n);
    rect(nr*ds+10*text.length()+l, 30+((float) n1)*dz/2-10+(dz-dn)/2-((n-n1)<2&&n>n1?0:0), dn, dn/((n-n1)<2&&n>n1?1.3f:1));
    rect(nr*ds+10*text.length(), 30+((float) n)*dz/2-10+((n-n1)<2&&n>n1?3:0)+(dz-dn)/2, dn, dn/((n-n1)<2&&n>n1?1.3f:1));
    line(nr*ds+10*text.length()+dn, 30+((float) n1)*dz/2-10+(dz-dn)/2-((n-n1)<2&&n>n1?0:0), nr*ds+10*text.length()+dn, 30+((float) n)*dz/2-10+((n-n1)<2&&n>n1?3:0)+dn/((n-n1)<2&&n>n1?1.3f:1));
    if (n1>n) line(nr*ds, 30+((float) n)*dz/2-10+(dz-dn)/2, nr*ds, 30+((float) n)*dz/2-10+(dz-dn)/2+3*dn);
  }
}
class Punctum_ {
  int n;
  int pcount=1;
  boolean bn;
  int t=0;
  Punctum_(int u, boolean b) {
    n=u;
    bn=b;
  }
  public void play(int r) {
    if (t!=3) amp2(dauer/(bn?2:1)*((t==2)?1.5f:1), toene[offset_toene+n]);
    toene[offset_toene+n]=stoene[offset_toene+n];
    //println("pun"+n);
  }
  Punctum_(int u, boolean b, int t) {
    n=u;
    bn=b;
    this.t=t;
  }
  public void paint(int nr) {
    int l=0;
    int tl=7;
    if (bn==true) {
      float offs=2.4f;
      quad(nr*ds+1+tl, 30+((float) n)*10+10-offs, nr*ds-6+tl+offs, 30+((float) n)*dz/2, nr*ds+1+tl, 30+((float) n)*dz/2-dz/2+offs, nr*ds+8+tl-offs, 30+((float) n)*10);
    } else {
      if (n<0) line(nr*ds-5, 30+((float) n)*dz/2-10+(dz-dn)/2+dn/2,nr*ds+dn+5, 30+((float) n)*dz/2-10+(dz-dn)/2+dn/2);
      if (t==2) line(nr*ds+dn, 30+((float) n)*dz/2-10+(dz-dn)/2, nr*ds+dn, 30+((float) n)*dz/2+30+(dz-dn)/2);
      if (t!=3) rect(nr*ds, 30+((float) n)*dz/2-10+(dz-dn)/2, dn, dn);
      if (t==3)line(660/scg-ds/2+dn/2, 30+((float) n)*dz/2+3+(dz-dn)/2, 660/scg-ds/2+dn/2, 30+((float) n)*dz/2-30+(dz-dn)/2);
      if (t==3) rect(660/scg-ds/2, 30+((float) n)*dz/2-10+(dz-dn)/2, dn/2, dn-2);
    }
  }
}
class Qui {
  int h, o;
  boolean over=false;
  boolean over2=false;
  float off=1;
  float ds_q=3.3f;
  float c=3;
  float a_q=ds_q*2/dn;
  float len=((float)dn)/c;
  Qui(int h, int o) {
    this.h=h;
    h=1;
    this.o=o;
  }
  public void play(int r){}
  public void paint(int nr) {
    nr-=off;
    int v=-o*dn;
    //rect(nr*ds, 30+((float) h)*dz/2-10+(dz-dn)/2, dn, dn);
    stroke(255,255,255,255);
    fill(255);
    float y1=30+((float) h)*dz/2-10+(dz-dn)/2+(over?1:0)-(over2?2:0);
    float y2=30+((float) h)*dz/2-10+(dz-dn)/2+dn-(over2?3:0)-1;
    //for (int i=1; i<dn; i+=3) line(nr*ds+i-v, 30+((float) h)*dz/2-10+(dz-dn)/2-1+(over?1:0)-(over2?2:0),nr*ds+i-v, 30+((float) h)*dz/2-10+(dz-dn)/2+1+(over?1:0)-(over2?2:0));
    //for (int i=2; i<dn; i+=3) line(nr*ds+i-v, 30+((float) h)*dz/2-10+(dz-dn)/2+dn-(over2?3:0)-2,nr*ds+i-v, 30+((float) h)*dz/2-10+(dz-dn)/2+dn-(over2?3:0));
    //for (int i=0; i<dn; i++) line(nr*ds+i-v,y1,nr*ds+i-v,y1+ds_q-(i*a_q)%ds_q);
    //for (int i=0; i<dn; i++) line(nr*ds+i-v,y2,nr*ds+i-v,y2-(i*a_q)%ds_q);
    for (int i=0; i<c; i++) triangle(nr*ds-v+len*i+len-1,y1,nr*ds-v+len*i,y1,nr*ds-v+len*i,y1+ds_q-1);
    for (int i=0; i<c; i++) triangle(nr*ds-v+len*i+len,y2-ds_q,nr*ds-v+len*i,y2+1,nr*ds-v+len*i+len,y2+1);
    fill(0);
    stroke(0);
  }
}
class Schluessel_ {
  boolean f=true;
  int a=0;
  Schluessel_(int s, boolean sch) {
    f=sch;
    a=s;
  }
  public void paint() {
    rect(35, 5+dz*a, 3, 10);
    rect(35, 15+dz*a, 6, 3);
    rect(35, 2+dz*a, 6, 3);
    if (f==true) {
      rect(28, 8+dz*a, 4, 4);
      line(28, dn*1.5f+dz*a, 28, 8+20*a);
    }
  }
  public void play(int r){
    int gz=-(2*a+(f?3:-1));
    for(int i=0;i<gtoene.length;i++) {
      int resetp=gtoene.length-1;
    stoene[i]=gtoene[i+gz-((i+gz>resetp)?7:0)+((i+gz<0)?7:0)]*((i+gz<0)?2:1)*((i+gz>resetp)?0.5f:1);
   // stoene[i]=gtoene[i+gz-((i+gz]
    toene[i]=stoene[i];
    }println(toene);
  }
  public void paint(int r) {
    rect(15+ds*r, 5+dz*a, 3, 10);
    rect(15+ds*r, 15+dz*a, 6, 3);
    rect(15+ds*r, 2+dz*a, 6, 3);
    if (f==true) {
      rect(ds*r+8, 8+dz*a, 4, 4);
      line(ds*r+8, 8+dz*a, ds*r+8, 8+dn+dz*a);
    }
  }
}
class Torculus_ {
  float dk=1;
  String text;
  float n;
  int n1;
  int n2;
  int tp=0;
  Torculus_(int u, int m, int o, String te) {
    n=u;
    n1=m;
    n2=o;
    text=te;
  }
  Torculus_(int u, int m, int o, String te, int tp) {
    n=u;
    n1=m;
    n2=o;
    text=te;
    this.tp=tp;
  }
  public void play(int nr) {
    amp2(dauer*0.6f*((tp>0)?2.4f:1), toene[offset_toene+(int)n]);
    amp2(dauer*0.6f*((tp>0)?2.4f:1), toene[offset_toene+(int)n1]);
    amp2(dauer*0.5f, toene[offset_toene+(int)n2]);
    toene[offset_toene+(int)n]=stoene[offset_toene+(int)n];
    toene[offset_toene+n1]=stoene[offset_toene+n1];
    toene[offset_toene+n2]=stoene[offset_toene+n2];
  }
  public void paint(int nr) {
    if (tp==0) {
      int l=0;
      //textMode(CENTER);
      //text(text,nr*dn+50,120);
      if (n<n1) l=20;
      rect(nr*ds, 30+((float) n)*dz/2-10+(dz-dn)/2, dn, dn);
      rect(nr*ds+10*text.length()+dn, 30+((float) n1)*dz/2-10+(dz-dn)/2, dn, dn);
      rect(nr*ds+10*text.length()+dn*2, 30+((float) n2)*dz/2-10+(dz-dn)/2, dn, dn);
      line(nr*ds+dn, 30+((float) n)*dz/2-8+(dz-dn)/2, nr*ds+dn, 30+((float) n1)*dz/2+dn-10+(dz-dn)/2);
      line(nr*ds+dn*2, 30+((float) n1)*dz/2-10+(dz-dn)/2, nr*ds+dn*2, 30+((float) n2)*dz/2-10+dn+(dz-dn)/2);
    } else {
      fill(0);
      float v1=30+((float) n)*dz/2-dn/2-2;
      float v2=30+((float) n1)*dz/2-dn/2;
      float v3=30+((float) n2)*dz/2-dn/2;
      if (v1!=v2) line(nr*ds, v1, nr*ds, v1+dn*2);
      float numb=1;
      if (n==n1) {
        v1=30+((float) n)*dz/2-dz/2;
        v2=30+((float) n1)*dz/2+dz-dz/2;
        dk=0.5f;
      }
      for (int i=0; i<=dk*ds; i++) {
        float pos=sin(PI/2*numb*i/(dk*ds))/sin(PI/2*numb);
        if (n!=n1) { 
          line(nr*ds+i, v1+(v2-v1)*pos+3, nr*ds+i, v1+(v2-v1)*pos+dn+2*(n1-n)*(1-pos)*dn*dn/(18*18));
        } else 
        line(nr*ds+i, v1+(dz-dn)*pos+3, nr*ds+i, v1+(dz-dn)*pos+dn);
      }
      if (n!=n1) line(nr*ds+dk*ds, v2+dn, nr*ds+dk*ds, v3+(dz-dn/2)/2-dn/4); 
      else line(nr*ds+dk*ds, v2, nr*ds+dk*ds, v3+(dz-dn/2)/2-dn/4);
      rect(nr*ds+dk*ds-dn/2, v3+(dz-dn/2)/2-dn/4-(abs(n1-n2)==1?1:0), dn/2, dn/2);
    }
  }
}
class Zeile {
  float scal=0.5f;
  Schluessel_ x;
  Group gr;
  Zeile() {
  }
  Zeile(Schluessel_ sc, Group g) {
    gr=g;
    x=sc;
  }
  public void play() {
    //println("sequenze start");
    //println(x==null&&gr==null);
    x.play(0);
    gr.play();
    //thread("requestData");
    line(30, 10+dz, 660/scal, 10+dz);
    line(30, 10+2*dz, 660/scal, 10+2*dz);
    line(30, 10+3*dz, 660/scal, 10+3*dz);
    line(30, 10+4*dz, 660/scal, 10+4*dz);
  }
  public void paint() {
    //println("sequenze start");
    //println(x==null&&gr==null);
    x.paint();
    gr.paint();
    //thread("requestData");
    line(30, 10+dz, 660/scal, 10+dz);
    line(30, 10+2*dz, 660/scal, 10+2*dz);
    line(30, 10+3*dz, 660/scal, 10+3*dz);
    line(30, 10+4*dz, 660/scal, 10+4*dz);
  }

  public void insert(String[] p) {
    Schluessel_ sch=new Schluessel_(0, true);
    // println(p.length);
    if (p.length>0) {
      String tr="";
      for (int i=0; i<p.length; i++) tr+=p[i]+"\n";
      //jtp.setText(tr);
      for (int i=0; i<p.length; i++) {
        String st=p[i]+" ";
        st=rep(st, " C", " 8");
        st=rep(st, " D", " 7");
        st=rep(st, " E", " 6");
        st=rep(st, " F", " 5");
        st=rep(st, " G", " 4");
        st=rep(st, " A", " 3");
        st=rep(st, " H", " 2");
        st=rep(st, " c", " 1");
        st=rep(st, " d", " 0");
        st=rep(st, " e", " -1");
        String[] splitted=st.split("b");
        if (splitted.length>0)
          for (int l=0; l<splitted.length-1; l++) {
            try {
              String bef=splitted[l].substring(splitted[l].length()-1, splitted[l].length());
              boolean cond=false;
              for (int k=0; k<10; k++) if (bef.equals(k+"")) cond=true;
              if (cond||bef.equals("e")) {
                st="b "+bef+"\n"+rep(st, bef+"b", bef);
               // println(st);
              }
            }
            catch(Exception e) {
            }
          }
        p[i]=st;
      }
      tr="";
      //  println(p.length);
      for (int i=0; i<p.length; i++) tr+=p[i]+"\n";
      p=tr.split("\n");
      Komponenten komp[]=new Komponenten[p.length];
      // println(x==null);
      for (int i=0; i<p.length; i++) {
        try {
          switch(p[i].split(" ")[0]) { 
          case "scal": 
            break;
          case "text": 
            break;
          case "M": 
            komp[i]=new Komponenten(markiert);
            break;
          case "pun": 
          //  println(p[i]);
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]); 
            else if (p[i].split(" ").length==2) komp[i]=new Komponenten(new Punctum_(PApplet.parseInt(p[i].split(" ")[1]), false, 0));
            else
              komp[i]=new Komponenten(new Punctum_(PApplet.parseInt(p[i].split(" ")[1]), (PApplet.parseInt(p[i].split(" ")[2])==1), PApplet.parseInt(p[i].split(" ")[2])));
            break; 
          case "b": 
           // println(p[i]);
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]); 
            else
              komp[i]=new Komponenten(new B_(PApplet.parseInt(p[i].split(" ")[1])));
            break; 
          case "q":
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]);  
            else if (p[i].split(" ").length==2) {
              komp[i]=new Komponenten(new Qui(PApplet.parseInt(p[i].split(" ")[1]), 0));
            } else 
            komp[i]=new Komponenten(new Qui(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]))); 
            komp[i].q.off=komp[i-1].pcount;
            Pes_ subj=komp[i-1].p1_;
            if (subj!=null&&(subj.n-subj.n1)<2&&subj.n>subj.n1) {
              if(komp[i].q.h==subj.n) komp[i].q.over=true;
              if(komp[i].q.h==subj.n1) komp[i].q.over2=true;
            }




            break;
          case "pes": 
           // println(p[i]);
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]); 
            else if (p[i].split(" ").length==3){
              komp[i]=new Komponenten(new Pes_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), ""));} 
            else if (PApplet.parseInt(p[i].split(" ")[3])==0)  komp[i]=new Komponenten(new Pes_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), ""));
              else if(PApplet.parseInt(p[i].split(" ")[3])==1) komp[i]=new Komponenten(new Clivis(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), ""));
            else if (PApplet.parseInt(p[i].split(" ")[3])==2){
              komp[i]=new Komponenten(new Torculus_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), "", 1));
              komp[i].t_.dk=dn/ds;
            }
            break;
          case "<":
            if (p[i].split(" ").length==5) komp[i]=new Komponenten(new Torculus_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), PApplet.parseInt(p[i].split(" ")[3]), "", PApplet.parseInt(p[i].split(" ")[4])));
            else if (p[i].split(" ").length==4) if (PApplet.parseInt(p[i].split(" ")[3])==0)  komp[i]=new Komponenten(new Pes_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), ""));
            else {
              komp[i]=new Komponenten(new Torculus_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), "", 1));
              komp[i].t_.dk=dn/ds;
            }else 
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]); 
            else if (p[i].split(" ").length==2) komp[i]=new Komponenten(new Punctum_(PApplet.parseInt(p[i].split(" ")[1]), false, 0));
            else
              komp[i]=new Komponenten(new Punctum_(PApplet.parseInt(p[i].split(" ")[1]), (PApplet.parseInt(p[i].split(" ")[2])==1), PApplet.parseInt(p[i].split(" ")[2])));
            

            break;
          case "torv": 
          //  println(p[i]);
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]); 
            else {
              komp[i]=new Komponenten(new Torculus_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), "", 1));
              komp[i].t_.dk=dn/ds;
            }

            break; 
          case "tor": 
          //  println(p[i]);
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]); 
            else
            {
              if (p[i].split(" ").length==4) komp[i]=new Komponenten(new Torculus_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), PApplet.parseInt(p[i].split(" ")[3]), ""));
              else komp[i]=new Komponenten(new Torculus_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2]), PApplet.parseInt(p[i].split(" ")[3]), "", PApplet.parseInt(p[i].split(" ")[4])));
            }
            break; 
          case "sc":
//println(p[i]);
            if (x!=null) {
              komp[i]=new Komponenten(new Schluessel_(PApplet.parseInt(p[i].split(" ")[1]), PApplet.parseInt(p[i].split(" ")[2])==1));
            } else {
              if (PApplet.parseInt(p[i].split(" ")[2])==0)x =new Schluessel_(PApplet.parseInt(p[i].split(" ")[1]), false);
              if (PApplet.parseInt(p[i].split(" ")[2])==1) x=new Schluessel_(PApplet.parseInt(p[i].split(" ")[1]), true);
            }
            break; 
          case "pa":
           // println(p[i]);
            if (p[i].split(" ").length==1) komp[i]=new Komponenten(p[i]); 
            else
              komp[i]=new Komponenten(new Paus_(PApplet.parseInt(p[i].split(" ")[1])));
            break; 
          case "gap":
            komp[i]=new Komponenten();
            break; 
          case "#":
            komp[i]=new Komponenten();
            break; 
          case "'gap":
            komp[i]=new Komponenten("gap");
            break; 
          case "'pa":
            komp[i]=new Komponenten("pa");
            break;
          case "'pes":
            komp[i]=new Komponenten("pes");
            break; 
          case "'tor":
            komp[i]=new Komponenten("tor");
            break; 
          case "'pun":
            komp[i]=new Komponenten("pun");
            break; 
          default: 
            komp[i]=new Komponenten(p[i]);
          }
        }
        catch(Exception e2) {
          if (warnings.getText().equals("Keine Fehler gefunden")) warnings.setText("");
          warnings.setText(warnings.getText()+"\n"+"Fehler in Zeile "+i+": "+p[i]);
        }
      }

      // println(x==null);
      gr= new Group(komp, "", 4);
    }
    if (x==null) x=sch;
   // println("sequenze complete");
  }
}
  public void settings() {  size(700, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "choral_Beta_1_0_3cop" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
